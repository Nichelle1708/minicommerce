import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ProductList() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8080/api/products')
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch products');
        }
        return response.json();
      })
      .then(data => setProducts(data))
      .catch(error => console.error('Error:', error));
  }, []);

  const deleteProduct = async (productId) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8080/api/products/${productId}`, {
        headers: {
            Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ3YXNzdXAxMjMiLCJpYXQiOjE3NTQzODc5MDIsImV4cCI6MTc1NDQ3NDMwMn0.-0DC8Br16NgHvYa4oDaIq2bTGH31cz5qpuXrpB7BhE4' // Replace with your JWT token
        }
      });

      setProducts(products.filter(p => p.id !== productId));
    } catch (error) {
      console.error('Failed to delete product:', error);
      alert('Failed to delete product');
    }
  };

  return (
    <div className="container mt-5">
  <h2 className="mb-4 text-center">Product List</h2>

  {products.length === 0 ? (
    <p className="text-center">No products found.</p>
  ) : (
    <div className="row justify-content-center">
      {products.map(product => (
        <div className="col-md-4 mb-4" key={product.id}>
          <div className="card shadow-sm text-center">
            <div className="card-body">
              <h5 className="card-title">{product.name}</h5>
              <p className="card-text">₹{product.price}</p>
              <button
                className="btn btn-danger"
                onClick={() => deleteProduct(product.id)}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )}
</div>

  );
}

export default ProductList;
